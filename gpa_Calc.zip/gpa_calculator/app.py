from flask import Flask, render_template, request, redirect, url_for, send_file
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import io
import os   

app = Flask(__name__)

# Grade points
grade_points = {
    "S": 10,
    "A+": 9,
    "A": 8,
    "B+": 7,
    "B": 6,
    "C": 5,
    "RA": 0,
    "SA": 0,
    "W": 0
}

# Subjects with credits
subjects = {

    "Semester 1": [
        ("MA25C05 Advanced Mathematical Methods", 4),
        ("CU25C01 Advanced Radiation Systems", 3),
        ("CU25C02 Modern Digital Communication Systems", 3),
        ("CU25C03 Advanced Digital Signal Processing", 3),
        ("CU25C04 Analog and Digital Electronic System Design", 3),
        ("CU25C05 Digital Communication Systems Laboratory", 2),
        ("CU25101 Technical Seminar", 1)
    ],

    "Semester 2": [
        ("CU25201 Radio Frequency Transceiver Design", 3),
        ("Programme Elective I", 3),
        ("CU25C06 Machine Learning", 3),
        ("CU25C07 Advanced Wireless Communication Networks", 3),
        ("CU25202 Advanced Communication Systems Laboratory", 2),
        ("Industry Oriented Course I", 2),
        ("CU25203 Industrial Training", 1),
        ("Self Learning Course", 1)
    ],

    "Semester 3": [
        ("Programme Elective II", 3),
        ("Programme Elective III", 3),
        ("Programme Elective IV", 3),
        ("Open Elective", 3),
        ("Industry Oriented Course II", 2),
        ("CU25301 Project Work I", 4)
    ],

    "Semester 4": [
        ("CU25401 Project Work II", 10)
    ]
}

# Temporary storage
student_data = {}



@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        student_data["name"] = request.form.get("name")
        student_data["email"] = request.form.get("email")
        return redirect(url_for("calculator"))

    return render_template("login.html")



@app.route("/calculator", methods=["GET", "POST"])
def calculator():

    semester = None
    gpa = None

    if request.method == "POST":

        semester = request.form.get("semester")
        grades = request.form.getlist("grade[]")
        credits = request.form.getlist("credit[]")

        total_points = 0
        total_credits = 0
        subject_details = []

        for (sub, _), g, c in zip(subjects[semester], grades, credits):

            if c.strip() == "":
                continue

            c = int(c)

            if g in grade_points:
                total_points += grade_points[g] * c
                total_credits += c

                subject_details.append({
                    "subject": sub,
                    "grade": g,
                    "credit": c
                })

        if total_credits > 0:
            gpa = round(total_points / total_credits, 2)

        # Store for PDF
        student_data["semester"] = semester
        student_data["gpa"] = gpa
        student_data["subjects"] = subject_details

    return render_template(
        "calculator.html",
        subjects=subjects,
        grade_points=grade_points,
        semester=semester,
        gpa=gpa
    )



@app.route("/download_pdf")
def download_pdf():

    buffer = io.BytesIO()

    doc = SimpleDocTemplate(buffer)
    styles = getSampleStyleSheet()

    elements = []

    elements.append(Paragraph("GPA Marksheet", styles['Title']))
    elements.append(Spacer(1, 20))

    elements.append(Paragraph(f"Name: {student_data.get('name','')}", styles['Normal']))
    elements.append(Paragraph(f"Email: {student_data.get('email','')}", styles['Normal']))
    elements.append(Paragraph(f"Semester: {student_data.get('semester','')}", styles['Normal']))
    elements.append(Spacer(1, 20))

    for sub in student_data.get("subjects", []):
        text = f"{sub['subject']} - Grade: {sub['grade']} (Credits: {sub['credit']})"
        elements.append(Paragraph(text, styles['Normal']))

    elements.append(Spacer(1, 20))
    elements.append(Paragraph(f"GPA: {student_data.get('gpa','')}", styles['Heading2']))

    doc.build(elements)
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name="marksheet.pdf",
        mimetype='application/pdf'
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))